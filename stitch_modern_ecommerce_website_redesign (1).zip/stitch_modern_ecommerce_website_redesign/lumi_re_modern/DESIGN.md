---
name: Lumière Modern
colors:
  surface: '#FFFFFF'
  surface-dim: '#ddd9d9'
  surface-bright: '#fcf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f1eded'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#44474a'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#75777a'
  outline-variant: '#c5c6ca'
  surface-tint: '#5d5e61'
  primary: '#000101'
  on-primary: '#ffffff'
  primary-container: '#1a1c1e'
  on-primary-container: '#838486'
  inverse-primary: '#c6c6c9'
  secondary: '#0053cd'
  on-secondary: '#ffffff'
  secondary-container: '#296cf0'
  on-secondary-container: '#fefcff'
  tertiary: '#010100'
  on-tertiary: '#ffffff'
  tertiary-container: '#201b17'
  on-tertiary-container: '#8b837d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e5'
  primary-fixed-dim: '#c6c6c9'
  on-primary-fixed: '#1a1c1e'
  on-primary-fixed-variant: '#454749'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b2c5ff'
  on-secondary-fixed: '#001848'
  on-secondary-fixed-variant: '#0040a1'
  tertiary-fixed: '#ebe0da'
  tertiary-fixed-dim: '#cfc5be'
  on-tertiary-fixed: '#201b17'
  on-tertiary-fixed-variant: '#4c4641'
  background: '#F5F4F0'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  accent-orange: '#FF5733'
  success: '#DCFCE7'
  danger: '#C00000'
  muted-border: '#E2E2E2'
typography:
  display-lg:
    fontFamily: Libre Caslon Text
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system is built for a premium e-commerce experience that balances high-end aesthetics with rigorous functional clarity. The brand personality is **sophisticated, confident, and editorial**, aiming to evoke a sense of curated luxury and effortless reliability.

The chosen design style is **Corporate / Modern with a Minimalist lens**. It leverages generous whitespace to let products breathe, while introducing depth through soft, ambient shadows. To maintain a "crisp" architectural feel, the system uses hairline borders and a high-contrast color strategy. The interface avoids unnecessary decoration, relying instead on precision typography and a "less but better" philosophy to guide the user's emotional response toward trust and desirability.

## Colors

The palette is anchored by a deep charcoal primary (`#1A1C1E`), replacing pure black to provide a softer, more premium feel for text and structural elements. The background uses a warm, off-white neutral (`#F5F4F0`) to reduce eye strain and provide a distinctive "paper" quality that contrasts beautifully against pure white surfaces.

Electric blue serves as the primary action color, ensuring high visibility for "Add to Cart" and primary navigation states. A vibrant sunset orange is used sparingly as a secondary accent for highlights, promotions, or "New" badges. Functional colors for success and danger are desaturated slightly to remain harmonious with the sophisticated tone of the system.

## Typography

This design system employs a high-contrast typographic pairing to establish an editorial hierarchy. **Libre Caslon Text** is used for headlines and display elements, bringing a sense of timeless elegance and authority. **Hanken Grotesk** handles all functional UI, body copy, and labels, providing a sharp, technical clarity that balances the traditional serif.

Key functional labels (like category tags or "Add to Cart" text) use a semi-bold weight with increased letter spacing and uppercase styling to ensure they are immediately distinguishable from descriptive body text.

## Layout & Spacing

The layout is built on a **12-column fluid grid** for desktop and a **4-column grid** for mobile. We use a base-4 spacing rhythm to ensure mathematical harmony across all components.

- **Desktop (1280px+):** 24px gutters with 64px side margins.
- **Tablet (768px - 1279px):** 20px gutters with 32px side margins.
- **Mobile (Up to 767px):** 16px gutters with 16px side margins.

Content should feel uncrowded. Use `xl` (40px) spacing between major sections and `md` (16px) for internal card padding. Functional elements like form fields and buttons should strictly adhere to the 4px grid for height and alignment.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** supplemented by **Ambient Shadows**.

1.  **Level 0 (Base):** The Page Background (`#F5F4F0`).
2.  **Level 1 (Surface):** White cards (`#FFFFFF`) with a hairline border (`#E2E2E2`) and no shadow. Used for secondary content or inactive states.
3.  **Level 2 (Elevated):** White cards with a soft, diffused shadow: `0 4px 20px rgba(26, 28, 30, 0.06)`. Used for product cards and primary interactive elements.
4.  **Level 3 (Overlay):** Used for modals and dropdowns, utilizing a deeper shadow: `0 12px 40px rgba(26, 28, 30, 0.12)`.

This approach ensures that depth feels natural and physical, avoiding the "flat" feel of the original wireframes while maintaining their structural integrity.

## Shapes

The design system utilizes **Soft (0.25rem)** roundedness to maintain a clean, modern aesthetic. 

- **Buttons & Inputs:** Use the standard 4px (0.25rem) radius for a "sharp but approachable" feel.
- **Cards:** Use the `rounded-lg` (8px) scale to provide a clear container-to-background distinction.
- **Badges/Chips:** Utilize the pill-shape (999px) for status indicators and categories to contrast against the more geometric UI elements.

## Components

### Buttons
- **Primary:** Solid Primary Color (`#1A1C1E`) with White text. Square-ish (4px radius) with 16px horizontal padding.
- **Action:** Solid Electric Blue (`#2B6EF2`) for "Add to Cart" or "Checkout".
- **Ghost:** Hairline border with the Primary color as text. No fill.

### Input Fields
- White fill with a 1px border (`#E2E2E2`). On focus, the border transitions to Electric Blue. Labels are always positioned above the field in `label-md` style.

### Product Cards
- Level 2 elevation. High-quality product imagery should occupy the top 70% of the card. Text is left-aligned with the brand in `label-sm` and price in `headline-md`.

### Chips & Tags
- Used for categories or filters. Pill-shaped with a light-grey background and Primary color text. Active states use the Electric Blue fill with White text.

### Selection Controls
- Checkboxes and Radios use a 2px border. When active, they use the Electric Blue fill with a white checkmark/dot.

### Navigation Bar
- Sticky at the top of the viewport. Uses the Background color (`#F5F4F0`) with a subtle bottom border to distinguish it from the content during scroll.